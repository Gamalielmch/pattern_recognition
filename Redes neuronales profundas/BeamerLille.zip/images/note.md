These are the images you will need for compiling a presentation.

Put them somewhere where LaTeX can find them.
